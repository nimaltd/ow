
/*
 * @file        ONEW
 * @author      Nima Askari
 * @version     1.0.0
 * @license     See the LICENSE file in the root folder.
 *
 * @github      https://www.github.com/nimaltd
 * @linkedin    https://www.linkedin.com/in/nimaltd
 * @youtube     https://www.youtube.com/@nimaltd
 * @instagram   https://instagram.com/github.nimaltd
 *
 * Copyright (C) 2025 Nima Askari - NimaLTD. All rights reserved.
 *
 */

#ifndef _OW_CONFIG_H_
#define _OW_CONFIG_H_

/*************************************************************************************************/
/** Configurations **/
/*************************************************************************************************/

/* USER CODE BEGIN OW_CONFIGURATION */

#define OW_USE_ALARM        1
#define OW_MAX_DATA_LEN     16
#define OW_MAX_DEVICE       5

#define OW_TIM_RST          500
#define OW_TIM_RST_DET      100
#define OW_TIM_WRITE_HIGH   65
#define OW_TIM_WRITE_LOW    10
#define OW_TIM_READ_LOW     10
#define OW_TIM_READ_SAMPLE  10
#define OW_TIM_READ_REST    65

/* USER CODE END OW_CONFIGURATION */

#if (OW_MAX_DATA_LEN < 16)
#error  OW_MAX_DATA_LEN should be bigger than 16
#endif

#if ((OW_MAX_DEVICE <= 0) || (OW_MAX_DEVICE >= 255))
#error  OW_MAX_DEVICE should be btween 0 and 255
#endif

/*************************************************************************************************/
/** End of File **/
/*************************************************************************************************/

#endif /* _OW_CONFIG_H_ */
